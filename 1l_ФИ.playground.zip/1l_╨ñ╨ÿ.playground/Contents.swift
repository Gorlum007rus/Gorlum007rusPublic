import UIKit

var greeting = "Hello, playground"

import Foundation


//Квадратное уравнение вариант 1

var a11 = 5.0
var b11 = 10.0
var c11 = 2.0
var x11 = 0.0
var x22 = 0.0

var R11 = pow(b11,2)-4*a11*c11

if (R11<0)
{
print("Корней нет")
}
if (R11==0)
{
x11 = (-b11+sqrt(R11))/(2*a11)
}
if (R11>0)
{
x11 = (-b11+sqrt(R11))/(2*a11)
x22 = (-b11+sqrt(R11))/(2*a11)
    print(x11)
    print(x22)
}



//Квадратное уравнение вариант 2
let a:Float = 1
let b:Float = 2
let c:Float = 3
var x1:Float
var x2:Float
var d:Float
var discriminant:Float
d = b * b - (4 * a * c)
if(d >= 0){
    discriminant = sqrt(d)
    x1 = (-b + discriminant) / (2 * a)
    x2 = (-b - (discriminant)) / (2 * a)
print(x1, x2)
}else if(d < 0){
    d = ((4 * a * c) - pow(b,2)) / (2 * a)
print(d)
}


 
//2.Даны катеты прямоугольного треугольника. Найти площадь, периметр и гипотенузу треугольника.
var v:Double = 6
var n:Double = 8
var m:Double = 10
var p:Double
p = v + n + m
m = sqrt(pow(v,2) + pow(n,2))
print("Периметр треугольника равен \(p)")
print("гипотенуза треугольника равна \(m)")


//3.Пользователь вводит сумму вклада в банк и годовой процент. Найти сумму вклада через 5 лет.

var deposit:Float = 1000
var percent:Float = 15
percent = percent / 100
var result1 = deposit + (deposit * percent)
var result2 = result1 + (result1 * percent)
var result3 = result2 + (result2 * percent)
var result4 = result3 + (result3 * percent)
var result5 = result4 + (result4 * percent)
var counter = 1
var time = [result1, result2,result3, result4, result5]
for i in time{
print("Через \(counter) год/лет сумма вклада будет равна \(i)")
    counter += 1
}
